
public class Planilla {
    String nombre, apellidos, cedula, puesto;
    int salarioBruto;
    double anualidad, escalafon, dedicacion, pensiones, bancoPopular, CCSS, vida, renta, colegioProfesional, salarioNeto;

    public Planilla() {
    }

    public Planilla(String nombre, String apellidos, String cedula, String puesto, int salarioBruto, double anualidad, double escalafon, double dedicacion, double pensiones, double bancoPopular, double CCSS, double vida, double renta, double colegioProfesional, double salarioNeto) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.cedula = cedula;
        this.puesto = puesto;
        this.salarioBruto = salarioBruto;
        this.anualidad = anualidad;
        this.escalafon = escalafon;
        this.dedicacion = dedicacion;
        this.pensiones = pensiones;
        this.bancoPopular = bancoPopular;
        this.CCSS = CCSS;
        this.vida = vida;
        this.renta = renta;
        this.colegioProfesional = colegioProfesional;
        this.salarioNeto = salarioNeto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public int getSalarioBruto() {
        return salarioBruto;
    }

    public void setSalarioBruto(int salarioBruto) {
        this.salarioBruto = salarioBruto;
    }

    public double getAnualidad() {
        return anualidad;
    }

    public void setAnualidad(double anualidad) {
        this.anualidad = anualidad;
    }

    public double getEscalafon() {
        return escalafon;
    }

    public void setEscalafon(double escalafon) {
        this.escalafon = escalafon;
    }

    public double getDedicacion() {
        return dedicacion;
    }

    public void setDedicacion(double dedicacion) {
        this.dedicacion = dedicacion;
    }

    public double getPensiones() {
        return pensiones;
    }

    public void setPensiones(double pensiones) {
        this.pensiones = pensiones;
    }

    public double getBancoPopular() {
        return bancoPopular;
    }

    public void setBancoPopular(double bancoPopular) {
        this.bancoPopular = bancoPopular;
    }

    public double getCCSS() {
        return CCSS;
    }

    public void setCCSS(double CCSS) {
        this.CCSS = CCSS;
    }

    public double getVida() {
        return vida;
    }

    public void setVida(double vida) {
        this.vida = vida;
    }

    public double getRenta() {
        return renta;
    }

    public void setRenta(double renta) {
        this.renta = renta;
    }

    public double getColegioProfesional() {
        return colegioProfesional;
    }

    public void setColegioProfesional(double colegioProfesional) {
        this.colegioProfesional = colegioProfesional;
    }

    public double getSalarioNeto() {
        return salarioNeto;
    }

    public void setSalarioNeto(double salarioNeto) {
        this.salarioNeto = salarioNeto;
    }
    
    
}
