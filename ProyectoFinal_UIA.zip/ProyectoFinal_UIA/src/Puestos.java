
public class Puestos {
    String titulo;
    int categoria;
    int salarioBruto;

    public Puestos() {
    }

    public Puestos(String titulo, int categoria, int salarioBruto) {
        this.titulo = titulo;
        this.categoria = categoria;
        this.salarioBruto = salarioBruto;
    }
        
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public int getSalarioBruto() {
        return salarioBruto;
    }

    public void setSalarioBruto(int salarioBruto) {
        this.salarioBruto = salarioBruto;
    }
           
}
