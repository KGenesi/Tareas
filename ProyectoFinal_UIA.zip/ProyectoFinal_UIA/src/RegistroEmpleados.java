
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class RegistroEmpleados extends javax.swing.JFrame {
    
    DefaultTableModel modelo = new DefaultTableModel();
    ArrayList<Empleados> listaEmpleados=new ArrayList<Empleados>();

    public RegistroEmpleados() {
        initComponents();
        this.setTitle("REGISTRO DE EMPLEADOS");
        this.setSize(875, 460);
        this.setLocationRelativeTo(null);
        
                      
        //Título de tabla
        modelo.addColumn("NOMBRE");
        modelo.addColumn("APELLIDOS");
        modelo.addColumn("CÉDULA");
        modelo.addColumn("NIVEL ACADÉMICO");
        modelo.addColumn("PUESTO");
        
        RegistroPuestos RPu = new RegistroPuestos();
        int controlador = RPu.model.getRowCount()-1;
        for(int i=0; i<controlador; i++){
            cboPuesto.addItem(RPu.model.getValueAt(i, 0).toString());
        }
        
        //Empleados existentes
        Empleados z=new Empleados();
        z.setNombre("Susana");
        z.setApellidos("Serrano Sibaja");
        z.setCedula("1-1111-1111");
        z.setCarreraProfesional("Universidad");
        z.setPuesto("Administrativo2");
        listaEmpleados.add(z);
        
        Empleados m=new Empleados();
        m.setNombre("Marco");
        m.setApellidos("Ramirez Vargas");
        m.setCedula("1-1234-1234");
        m.setCarreraProfesional("Colegio");
        m.setPuesto("Personal de apoyo");
        listaEmpleados.add(m);
        refrescarTabla();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblEmpleados = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtApellidos = new javax.swing.JTextField();
        txtCedula = new javax.swing.JTextField();
        cboNivelAcademico = new javax.swing.JComboBox<>();
        btnAgregarEmpleado = new javax.swing.JButton();
        btnLimpiarEmpleado = new javax.swing.JButton();
        btnActualizarEmpleado = new javax.swing.JButton();
        btnBorrarEmpleado = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        cboPuesto = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblEmpleados);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 230, 858, 200));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Nombre");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 110, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Apellidos");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 110, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Cédula");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 110, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Nivel Académico");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, -1, -1));
        getContentPane().add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 30, 250, -1));
        getContentPane().add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 70, 250, -1));

        txtCedula.setToolTipText("Debe contener guiones");
        txtCedula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCedulaKeyTyped(evt);
            }
        });
        getContentPane().add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, 250, -1));

        cboNivelAcademico.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Universidad", "Colegio", "Técnico" }));
        getContentPane().add(cboNivelAcademico, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 150, 250, -1));

        btnAgregarEmpleado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAgregarEmpleado.setText("Agregar");
        btnAgregarEmpleado.setMaximumSize(new java.awt.Dimension(97, 26));
        btnAgregarEmpleado.setMinimumSize(new java.awt.Dimension(97, 26));
        btnAgregarEmpleado.setPreferredSize(new java.awt.Dimension(97, 26));
        btnAgregarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarEmpleadoActionPerformed(evt);
            }
        });
        getContentPane().add(btnAgregarEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 80, 100, -1));

        btnLimpiarEmpleado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLimpiarEmpleado.setText("Limpiar");
        btnLimpiarEmpleado.setMaximumSize(new java.awt.Dimension(97, 26));
        btnLimpiarEmpleado.setMinimumSize(new java.awt.Dimension(97, 26));
        btnLimpiarEmpleado.setPreferredSize(new java.awt.Dimension(97, 26));
        btnLimpiarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarEmpleadoActionPerformed(evt);
            }
        });
        getContentPane().add(btnLimpiarEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 80, 90, -1));

        btnActualizarEmpleado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnActualizarEmpleado.setText("Actualizar");
        btnActualizarEmpleado.setMaximumSize(new java.awt.Dimension(85, 26));
        btnActualizarEmpleado.setMinimumSize(new java.awt.Dimension(85, 26));
        btnActualizarEmpleado.setPreferredSize(new java.awt.Dimension(85, 26));
        btnActualizarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarEmpleadoActionPerformed(evt);
            }
        });
        getContentPane().add(btnActualizarEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 130, 100, -1));

        btnBorrarEmpleado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBorrarEmpleado.setText("Borrar");
        btnBorrarEmpleado.setMaximumSize(new java.awt.Dimension(97, 26));
        btnBorrarEmpleado.setMinimumSize(new java.awt.Dimension(97, 26));
        btnBorrarEmpleado.setPreferredSize(new java.awt.Dimension(97, 26));
        btnBorrarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarEmpleadoActionPerformed(evt);
            }
        });
        getContentPane().add(btnBorrarEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 130, 90, -1));

        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        getContentPane().add(btnVolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Puesto");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 110, -1));

        getContentPane().add(cboPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, 250, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    
    private void btnAgregarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarEmpleadoActionPerformed
        Empleados x=new Empleados();
        x.setNombre(txtNombre.getText());
        x.setApellidos(txtApellidos.getText());
        x.setCedula(txtCedula.getText());
        x.setCarreraProfesional(cboNivelAcademico.getSelectedItem().toString());
        x.setPuesto(cboPuesto.getSelectedItem().toString());
        listaEmpleados.add(x);
        refrescarTabla();
    }//GEN-LAST:event_btnAgregarEmpleadoActionPerformed

    private void btnLimpiarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarEmpleadoActionPerformed
        txtNombre.setText("");
        txtApellidos.setText("");
        txtCedula.setText("");
        cboNivelAcademico.setSelectedIndex(0);
        cboPuesto.setSelectedIndex(0);
    }//GEN-LAST:event_btnLimpiarEmpleadoActionPerformed

    private void btnActualizarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarEmpleadoActionPerformed
        
        int selectedRowIndex = tblEmpleados.getSelectedRow();
        
        String upNombre = modelo.getValueAt(selectedRowIndex, 0).toString();
        String upApellidos = modelo.getValueAt(selectedRowIndex, 1).toString();
        String upCedula = modelo.getValueAt(selectedRowIndex, 2).toString();
        String upCarrera = modelo.getValueAt(selectedRowIndex, 3).toString();
        String upPuesto = modelo.getValueAt(selectedRowIndex, 4).toString();
        
        String newNombre = JOptionPane.showInputDialog(null, "Digite el nombre", upNombre);
        String newApellidos = JOptionPane.showInputDialog(null, "Digite los apellidos", upApellidos);
        String newCedula = JOptionPane.showInputDialog(null, "Digite el número de cédula", upCedula);
        String newCarrera = JOptionPane.showInputDialog(null, "Digite la carrera académica", upCarrera);
        String newPuesto = JOptionPane.showInputDialog(null, "Digite el puesto", upPuesto);
        
        modelo.removeRow(selectedRowIndex);
        listaEmpleados.remove(selectedRowIndex);
        
        Empleados y=new Empleados();
        y.setNombre(newNombre);
        y.setApellidos(newApellidos);
        y.setCedula(newCedula);
        y.setCarreraProfesional(newCarrera);
        y.setPuesto(newPuesto);
        listaEmpleados.add(y);
        refrescarTabla();
        
    }//GEN-LAST:event_btnActualizarEmpleadoActionPerformed

    private void btnBorrarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarEmpleadoActionPerformed
        
        int selectedRowIndex = tblEmpleados.getSelectedRow();
        
        modelo.removeRow(selectedRowIndex);
        listaEmpleados.remove(selectedRowIndex);
    }//GEN-LAST:event_btnBorrarEmpleadoActionPerformed

    private void txtCedulaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCedulaKeyTyped
        if(txtCedula.getText().length() >= 11) {
            evt.consume();
        }
    }//GEN-LAST:event_txtCedulaKeyTyped

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        PantallaPrincipal PP = new PantallaPrincipal();
        PP.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    
    public void refrescarTabla(){
        while(modelo.getRowCount()>0){
            modelo.removeRow(0);
        }
        
        for (Empleados x : listaEmpleados){
            Object e[]=new Object[5];
            e[0]=x.getNombre();
            e[1]=x.getApellidos();
            e[2]=x.getCedula();
            e[3]=x.getCarreraProfesional();
            e[4]=x.getPuesto();
            modelo.addRow(e);
        }
        txtNombre.setText("");
        txtApellidos.setText("");
        txtCedula.setText("");
        cboNivelAcademico.setSelectedIndex(0);
        cboPuesto.setSelectedIndex(0);
        tblEmpleados.setModel(modelo);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroEmpleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroEmpleados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizarEmpleado;
    private javax.swing.JButton btnAgregarEmpleado;
    private javax.swing.JButton btnBorrarEmpleado;
    private javax.swing.JButton btnLimpiarEmpleado;
    private javax.swing.JButton btnVolver;
    private javax.swing.JComboBox<String> cboNivelAcademico;
    private javax.swing.JComboBox<String> cboPuesto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblEmpleados;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
