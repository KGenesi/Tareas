
public class CarreraProfesional {
    String docente, carreraProfesional;

    public CarreraProfesional() {
    }

    public CarreraProfesional(String docente, String carreraProfesional) {
        this.docente = docente;
        this.carreraProfesional = carreraProfesional;
    }

    public String getDocente() {
        return docente;
    }

    public void setDocente(String docente) {
        this.docente = docente;
    }

    public String getCarreraProfesional() {
        return carreraProfesional;
    }

    public void setCarreraProfesional(String carreraProfesional) {
        this.carreraProfesional = carreraProfesional;
    }
    
    
}
