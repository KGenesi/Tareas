
public class LoginUser {
    static String rolUsuario;
    static int controladorE;
    static int controladorU;
    static int controladorP;

    public LoginUser() {
    }

    public String getRolUsuario() {
        return rolUsuario;
    }

    public void setRolUsuario(String usuario) {
        LoginUser.rolUsuario = usuario;
    }

    public static int getControladorE() {
        return controladorE;
    }

    public static void setControladorE(int controladorE) {
        LoginUser.controladorE = controladorE;
    }

    public static int getControladorU() {
        return controladorU;
    }

    public static void setControladorU(int controladorU) {
        LoginUser.controladorU = controladorU;
    }

    public static int getControladorP() {
        return controladorP;
    }

    public static void setControladorP(int controladorP) {
        LoginUser.controladorP = controladorP;
    }
    
}

