
import javax.swing.table.DefaultTableModel;


public class RegistroPuestos extends javax.swing.JFrame {
    Bienvenido B = new Bienvenido();
    Bienvenida Ba = new Bienvenida();

    public RegistroPuestos() {
        //DefaultTableModel model = (DefaultTableModel) tblPuestos.getModel();
        //ArrayList<Puestos> listaPuestos=new ArrayList<Puestos>();
        initComponents();
        this.setTitle("REGISTRO DE PUESTOS");
        this.setSize(875, 460);
        this.setLocationRelativeTo(null);
        
        System.out.print(B.getControllerE());
        /*if(B.getControllerPu()==5){
            //Título de tabla
            model.addColumn("TÍTULO");
            model.addColumn("CATEGORÍA");
            model.addColumn("SALARIO BRUTO");
            
            Puestos a=new Puestos();
            a.setTitulo("Personal de apoyo");
            a.setCategoria(1);
            a.setSalarioBruto(250000);
            listaPuestos.add(a);
        
            Puestos b=new Puestos();
            b.setTitulo("Administrativo1");
            b.setCategoria(1);
            b.setSalarioBruto(320000);
            listaPuestos.add(b);
        
            Puestos c=new Puestos();
            c.setTitulo("Técnico especializado");
            c.setCategoria(1);
            c.setSalarioBruto(415000);
            listaPuestos.add(c);
        
            Puestos d=new Puestos();
            d.setTitulo("Administrativo2");
            d.setCategoria(2);
            d.setSalarioBruto(500000);
            listaPuestos.add(d);
        
            Puestos e=new Puestos();
            e.setTitulo("Profesional de apoyo");
            e.setCategoria(2);
            e.setSalarioBruto(580000);
            listaPuestos.add(e);
        
            Puestos f=new Puestos();
            f.setTitulo("Docente Licenciado");
            f.setCategoria(2);
            f.setSalarioBruto(620000);
            listaPuestos.add(f);
        
            Puestos g=new Puestos();
            g.setTitulo("Docente Máster");
            g.setCategoria(2);
            g.setSalarioBruto(750000);
            listaPuestos.add(g);
        
            Puestos h=new Puestos();
            h.setTitulo("Jefe1");
            h.setCategoria(2);
            h.setSalarioBruto(800000);
            listaPuestos.add(h);
        
            Puestos i=new Puestos();
            i.setTitulo("Jefe2");
            i.setCategoria(2);
            i.setSalarioBruto(950000);
            listaPuestos.add(i);
        
            Puestos j=new Puestos();
            j.setTitulo("Director");
            j.setCategoria(2);
            j.setSalarioBruto(1500000);
            listaPuestos.add(j);
            B.setControllerPu(1);
        }*/
        //Puestos existentes

        //refrescarTabla();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        tblPuestos = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtTitulo = new javax.swing.JTextField();
        txtCategoria = new javax.swing.JTextField();
        txtSalarioBruto = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnBorrar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblPuestos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"Test", "2", "123456"}
            },
            new String [] {
                "TÍTULO", "CATEGORÍA", "SALARIO BRUTO"
            }
        ));
        jScrollPane2.setViewportView(tblPuestos);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 840, 240));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Título");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, 90, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Categoría");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 90, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Salario Bruto");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, 90, -1));
        getContentPane().add(txtTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 30, 220, -1));
        getContentPane().add(txtCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, 220, -1));
        getContentPane().add(txtSalarioBruto, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 110, 220, -1));

        btnAgregar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        getContentPane().add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 60, 80, -1));

        btnLimpiar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 60, 80, -1));

        btnActualizar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });
        getContentPane().add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 110, -1, -1));

        btnBorrar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBorrar.setText("Borrar");
        btnBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnBorrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 110, 80, -1));

        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        getContentPane().add(btnVolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        DefaultTableModel model = (DefaultTableModel) tblPuestos.getModel();

        Object e[]=new Object[3];
        e[0]=txtTitulo.getText();
        e[1]=Integer.parseInt(txtCategoria.getText());
        e[2]=Integer.parseInt(txtSalarioBruto.getText());
        model.addRow(e);
        //refrescarTabla();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        txtTitulo.setText("");
        txtCategoria.setText("");
        txtSalarioBruto.setText("");
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        /*int selectedRowIndex = tblPuestos.getSelectedRow();
        
        String upTitulo = Ba.model.getValueAt(selectedRowIndex, 0).toString();
        String upCategoria = Ba.model.getValueAt(selectedRowIndex, 1).toString();
        String upSalarioBruto = Ba.model.getValueAt(selectedRowIndex, 2).toString();
        
        String newTitulo = JOptionPane.showInputDialog(null, "Digite el título", upTitulo);
        String newCategoria = JOptionPane.showInputDialog(null, "Digite la categoría", upCategoria);
        String newSalarioBruto = JOptionPane.showInputDialog(null, "Digite el salario bruto", upSalarioBruto);
        
        Ba.model.removeRow(selectedRowIndex);
        Ba.listaPuestos.remove(selectedRowIndex);
        
        Puestos y=new Puestos();
        y.setTitulo(newTitulo);
        y.setCategoria(Integer.parseInt(newCategoria));
        y.setSalarioBruto(Integer.parseInt(newSalarioBruto));
        Ba.listaPuestos.add(y);
        refrescarTabla();*/
        
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarActionPerformed
        int selectedRowIndex = tblPuestos.getSelectedRow();
        
        /*Ba.model.removeRow(selectedRowIndex);
        Ba.listaPuestos.remove(selectedRowIndex);*/
    }//GEN-LAST:event_btnBorrarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        PantallaPrincipal PP = new PantallaPrincipal();
        PP.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    public void refrescarTabla(){
        /*while(Ba.model.getRowCount()>0){
            Ba.model.removeRow(0);
        }
        
        for (Puestos x : Ba.listaPuestos){
            Object e[]=new Object[3];
            e[0]=x.getTitulo();
            e[1]=x.getCategoria();
            e[2]=x.getSalarioBruto();
            Ba.model.addRow(e);
        }
        System.out.print("P" + Ba.model.getRowCount());
        txtTitulo.setText("");
        txtCategoria.setText("");
        txtSalarioBruto.setText("");
        tblPuestos.setModel(Ba.model);*/
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroPuestos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroPuestos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroPuestos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroPuestos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroPuestos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblPuestos;
    private javax.swing.JTextField txtCategoria;
    private javax.swing.JTextField txtSalarioBruto;
    private javax.swing.JTextField txtTitulo;
    // End of variables declaration//GEN-END:variables
}
