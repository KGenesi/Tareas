
public class Bienvenido {
    static int controllerE;
    static int controllerPu;
    static int controllerPl;

    public Bienvenido() {
    }

    public static int getControllerE() {
        return controllerE;
    }

    public static void setControllerE(int controllerE) {
        Bienvenido.controllerE = controllerE;
    }

    public static int getControllerPu() {
        return controllerPu;
    }

    public static void setControllerPu(int controllerPu) {
        Bienvenido.controllerPu = controllerPu;
    }

    public static int getControllerPl() {
        return controllerPl;
    }

    public static void setControllerPl(int controllerPl) {
        Bienvenido.controllerPl = controllerPl;
    }
    
    
}
